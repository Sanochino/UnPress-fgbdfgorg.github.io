<?php
/**
 * @copyright 2017 Roman Parpalak
 * @license   MIT
 */

namespace S2\Rose\Exception;

/**
 * Class InvalidArgumentException
 */
class InvalidArgumentException extends RuntimeException
{

}
