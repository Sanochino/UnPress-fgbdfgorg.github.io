<?php foreach ($content['scripts'] as $script): ?>
<script type="text/javascript" src="<?= $script ?>"></script>
<?php endforeach ?>