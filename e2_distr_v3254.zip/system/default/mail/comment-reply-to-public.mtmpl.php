<?= $content['reply-text']?> 
	<?= $content['blog-author'] ?> 

<?= $content['comment-href'] ?> 

<?= _S ('em--comment-replied-at') ?>:
<?= $content['comment-text']?> 
	<?= $content['commenter'] ?> 


<?= _S ('em--unsubscribe') ?>:
<?= $content['unsubscribe-href'] ?> 


<?= _S ('em--created-automatically') ?>