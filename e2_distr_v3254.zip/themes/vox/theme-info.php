<?php return array (

  'index' => 11,

  'display_name' => array (
    'en' => 'Vox',
    'ru' => 'Вокс',
  ),

  'colors' => array (
    'background' => '#f1f3f2',
    'headings' => '#4C4E4D',
    'text' => '#4C4E4D',
    'link' => '#4f7177',
  ),

  'based_on' => 'plain',
  'meta_viewport' => 'width=device-width, initial-scale=1',

); ?>